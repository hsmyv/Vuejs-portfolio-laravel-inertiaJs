<script setup>
</script>
<template>
    <footer class="bg-sky-200 border-gray-200 dark:bg-blue-900 py-12">
        <div class="container mx-auto">
            <div class="
          flex flex-col
          md:flex-row
          space-y-6
          lg:space-y-0
          items-center
          justify-between
        ">
                <div class="flex space-x-6 items-center justify-center">
                    <img class="h-8 w-auto" src="https://th.bing.com/th/id/R.0f8f96cd5a41d48ff45a75120dc9c610?rik=zh49jPCx5KaqyA&pid=ImgRaw&r=0" alt="HSTUDIO" />
                </div>
                <p class="block py-2 pl-3 pr-4 text-white rounded md:bg-transparent md:text-slate-900 md:p-0 dark:text-white opacity-80 text-[15px]">
                    &copy; 2023 HSTUDIO All right reserved.
                </p>
            </div>
        </div>
    </footer>
</template>
