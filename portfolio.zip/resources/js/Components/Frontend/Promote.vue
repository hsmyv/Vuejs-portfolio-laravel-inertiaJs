<template>
    <div class=" bg-sky-200
      dark:bg-blue-900">
        <div class="
        container
        max-w-7xl
        mx-auto
        py-12
        px-4
        sm:px-6
        lg:flex lg:items-center lg:justify-between lg:py-16 lg:px-8
      ">
            <h2 class="
          text-3xl
          font-bold
          tracking-tight
          text-gray-900
          sm:text-4xl
        ">
                <span class="block  dark:text-white text-slate-900">Would you like to learn more about my background?</span>
                <span class="block dark:text-white text-slate-900">You can learn more about my professional capabilities.</span>
            </h2>
            <div class="mt-8 flex lg:mt-0 lg:flex-shrink-0">
                <div class="inline-flex rounded-md shadow">
                    <a href="cv/download" class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-white
              hover:bg-cyan-100
              dark:bg-blue-600
              px-5
              py-3
              text-base
              font-medium
              text-slate-900
              dark:text-white
              dark:hover:bg-blue-700
            ">Get My CV</a>
                </div>
            </div>
        </div>
    </div>
</template>

