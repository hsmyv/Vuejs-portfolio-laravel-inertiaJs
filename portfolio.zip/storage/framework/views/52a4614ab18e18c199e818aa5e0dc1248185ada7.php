<h1>Contact from <?php echo e($name); ?></h1>
<h3>Email:<?php echo e($email); ?></h3>
<p><?php echo $body; ?></p>
<?php /**PATH D:\Hasan\Vue projects\portfolio\resources\views/emails/contact.blade.php ENDPATH**/ ?>