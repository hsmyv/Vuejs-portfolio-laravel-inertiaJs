<h1>Contact from {{$name}}</h1>
<h3>Email:{{$email}}</h3>
<p>{!!$body!!}</p>
